import pandas as pd  #  import: bring in the pandas library and alias as pd
import re #  # import: bring in the regex library and alias as re